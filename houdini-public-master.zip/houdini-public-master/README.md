# Houdini (iOS 10-10.3.2 and iOS 11-11.3.1)

by Abraham Masri @cheesecakeufo - exploits by (@i41nbeer)

[Download here](https://iabem97.github.io/houdini_website/)

# How do I install this?
You probably should just just go [here](http://iabem97.github.io/houdini_website) and follow the instructions.

For iOS 11.2 to 11.3.1, you _need_ a paid developer account to build Houdini. Otherwise, please remove 'MultiPath' entitlement from the .entitlements file and continue.


If you feel a bit more adventurous and want to see logs, use Xcode on a Mac (or a macOS VM), download the project and install XCode.

Open the project "blue icon" and hit run.)

# Is this a full jailbreak?
Nope. Once you run it, Cydia will NOT be installed.

This is not meant to be a full jailbreak. I initially created it as a PoC (to learn about the iOS file system structure and how far we can modify the system without a full jailbreak) but then it turned into a project for everyone to use.

# How can I help?
If you're interested in taking Houdini to the next level and add more features, go for it.

You might notice that the code base is thousands(-ish) of lines. Why? I turned the PoC into a project that will be used publicly by users and it wasn't the best decision cause it made the code base look very messy. A lot of repeated functions or unnecessary code was added. A clean-up would be nice :)

