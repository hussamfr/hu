//
//  ClearCacheViewController.h
//  nsxpc2pc
//
//  Created by Abraham Masri on 11/21/17.
//  Copyright © 2017 cheesecakeufo. All rights reserved.
//

#ifndef ClearCacheViewController_h
#define ClearCacheViewController_h

@interface ClearCacheViewController : UIViewController


@end


#endif /* ClearCacheViewController_h */
