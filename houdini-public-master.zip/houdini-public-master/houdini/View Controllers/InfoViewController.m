//
//  InfoViewController.m
//  Saigon
//
//  Created by Abraham Masri on 11/29/17.
//  Copyright © 2017 cheesecakeufo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#include "Utilities.h"

@interface InfoViewController : UIViewController


@end

@interface InfoViewController ()

@end

@implementation InfoViewController


- (IBAction)dismissTapped:(id)sender {

    [self dismissViewControllerAnimated:YES completion:nil];

}


@end
