//
//  WidgetObject.m
//  houdini
//
//  Created by Abraham Masri on 5/7/18.
//  Copyright © 2018 cheesecakeufo. All rights reserved.
//

#include "WidgetObject.h"

@implementation WidgetObject
@end
