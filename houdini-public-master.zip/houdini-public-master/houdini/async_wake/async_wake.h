#ifndef async_wake_h
#define async_wake_h

#include <dlfcn.h>
#include <copyfile.h>
#include <stdio.h>
#include <spawn.h>
#include <unistd.h>
#include <mach/mach.h>
#include <mach-o/dyld.h>
#include <sys/stat.h>
#include <sys/mount.h>
#include <sys/utsname.h>


extern uint64_t kernel_task;
void go(void);

#endif /* async_wake_h */
