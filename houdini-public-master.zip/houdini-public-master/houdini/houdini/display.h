//
//  display.h
//  nsxpc2pc
//
//  Created by Abraham Masri on 11/25/17.
//  Copyright © 2017 cheesecakeufo. All rights reserved.
//

#ifndef display_h
#define display_h

void change_resolution(int, int);

#endif /* display_h */
