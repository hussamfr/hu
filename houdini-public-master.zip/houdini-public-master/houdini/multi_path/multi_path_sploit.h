#ifndef multi_path_sploit_h
#define multi_path_sploit_h

kern_return_t multi_path_go(void);

#endif
