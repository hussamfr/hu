#ifndef sploit_h
#define sploit_h

#include <stdint.h>

uint64_t find_blr_x19_gadget();
#endif
