//
//  triple_fetch_strategy.h
//  houdini
//
//  Created by Abraham Masri on 12/7/17.
//  Copyright © 2017 cheesecakeufo. All rights reserved.
//

#ifndef triple_fetch_strategy_h
#define triple_fetch_strategy_h

#include "strategy_control.h"

strategy triple_fetch_strategy();

#endif /* triple_fetch_strategy_h */
