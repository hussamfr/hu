//
//  upper_echelon_strategy.h
//  houdini
//
//  Created by Abraham Masri on 05/04/2018.
//  Copyright © 2018 cheesecakeufo. All rights reserved.
//

#ifndef upper_echelon_strategy_h
#define upper_echelon_strategy_h

#include "strategy_control.h"

strategy upper_echelon_strategy();

#endif /* upper_echelon_strategy_h */
